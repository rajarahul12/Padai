const data = [
  {
    image:"http://127.0.0.1:8081/randomimage?ma",
    name:"Manjunath",
    date:"10 day Ago",
    text:"Hello peeps, howz react going?"
  },
  {
    image:"http://127.0.0.1:8081/randomimage?sa",
    name:"Sandhya",
    date:"1 year Ago",
    text:"Hello, howz iOS going? today or tomorrow?"
  },
  {
    image:"http://127.0.0.1:8081/randomimage?ra",
    name:"Rahul",
    date:"13 months Ago",
    text:"Hello guys, howz react going?"
  },
  {
    image:"http://127.0.0.1:8081/randomimage?sr",
    name:"Srutha",
    date:"11 weeks Ago",
    text:"Hello people, howz angular going tomorrow ?"
  },
  {
    image:"http://127.0.0.1:8081/randomimage?ch",
    name:"Charan",
    date:"1 day Ago",
    text:"Hello peeps, howz react going?"
  },
  {
    image:"http://127.0.0.1:8081/randomimage?ka",
    name:"Kapil",
    date:"100 years Ago",
    text:"Hello peeps, howz push going today?"
  },
  {
    image:"http://127.0.0.1:8081/randomimage?vi",
    name:"Vidyasagar",
    date:"1 day Ago",
    text:"Hello peeps, howz react going?"
  }
];

export default data;
