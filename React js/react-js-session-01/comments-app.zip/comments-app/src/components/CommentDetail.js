import React from 'react';

const CommentDetail = (props) => {
  return (
    <div className="comment">
      <a className="avatar">
        <img src={props.image}/>
      </a>
      <div className="content">
        <a className="author">{props.name}</a>
        <div className="metadata">
          <div className="date">{props.date}</div>
        </div>
        <div className="text">
          <p>{props.text}</p>
        </div>
        <div className="actions">
          <a className="reply">Reply</a>
        </div>
      </div>
    </div>
  );
}

export default CommentDetail;
