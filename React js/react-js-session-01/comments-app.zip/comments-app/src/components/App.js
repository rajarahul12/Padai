import React from 'react';

import CommentDetail from './CommentDetail';

import commentData from '../static-comment-data/comments-data';

const createCommentList = () => {
  return commentData.map(
            comment => {
              return <CommentDetail
                        key={comment.name}
                        image={comment.image}
                        name={comment.name}
                        date={comment.date}
                        text={comment.text}
                     />
            }
          )
}


const App = () => {
  console.log(commentData);
  return (
    <div className="ui comments">
      {createCommentList()}
    </div>
  );
}

export default App;
