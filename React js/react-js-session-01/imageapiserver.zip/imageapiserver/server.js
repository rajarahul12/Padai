const express = require('express')
const app = express();
const fs = require('fs')
const faker = require('faker');
const https = require('https');
const port = 8081



app.get('/randomimage', (req, res) => {
  https.get(faker.image.avatar(), function(response) {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    response.pipe(res);
  });
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))
